# 14) src/server/api/__init__.py  (om du vill ha explicit export)
# tom eller: from .health import router as health_router

